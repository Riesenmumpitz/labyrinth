//
// Diese Datei wurde mit der JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 generiert 
// Siehe <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Änderungen an dieser Datei gehen bei einer Neukompilierung des Quellschemas verloren. 
// Generiert: 2015.04.28 um 10:17:14 AM CEST 
//


package generatedFromXsd;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für BeispielAttribut.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * <p>
 * <pre>
 * &lt;simpleType name="BeispielAttribut">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TYPE1"/>
 *     &lt;enumeration value="TYPE2"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BeispielAttribut")
@XmlEnum
public enum BeispielAttribut {

    @XmlEnumValue("TYPE1")
    TYPE_1("TYPE1"),
    @XmlEnumValue("TYPE2")
    TYPE_2("TYPE2");
    private final String value;

    BeispielAttribut(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BeispielAttribut fromValue(String v) {
        for (BeispielAttribut c: BeispielAttribut.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
