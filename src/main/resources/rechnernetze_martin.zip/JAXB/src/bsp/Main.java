package bsp;

import generatedFromXsd.BeispielAttribut;
import generatedFromXsd.Beispielobjekt;
import generatedFromXsd.ObjectFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class Main {

    public static void main(String[] args) throws Throwable {
        // Umgebung konfigurieren/vorbereiten
        ObjectFactory of = new ObjectFactory();
        JAXBContext jc = JAXBContext.newInstance(Beispielobjekt.class);
        Marshaller marshaller = jc.createMarshaller();
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        // Objekt erstellen und mit Inhalt fuellen
        Beispielobjekt object = of.createBeispielobjekt();
        object.setData1("Hallo Welt");
        object.setData2(1337);
        object.setType(BeispielAttribut.TYPE_1);

        // Marshalling
        // Einmal Objekt auf in OutputStream System.out marshallen
        marshaller.marshal(object, System.out);
        // Und einmal in XML-Datei marshallen
        marshaller.marshal(object, new FileOutputStream(new File("Test.xml")));

        // Unmarshalling
        // Hier Objekt erzeugen aus XML-Datei
        Beispielobjekt objectFromXmlFile = (Beispielobjekt) unmarshaller
                .unmarshal(new FileInputStream(new File("Test.xml")));

        // Testen des Objektes
        System.out.println(objectFromXmlFile.getData1() + " : " + objectFromXmlFile.getData2());

        // Das ganze nochmal mit StringWriter und String
        // Marshalling
        StringWriter stringWriter = new StringWriter();
        marshaller.marshal(object, stringWriter);
        String serializedXML = stringWriter.toString();
        // Dieser String koennte nun z.B. mit writeUTF ueber das Netz
        // gehen...
        // Unmarshalling
        StringReader stringReader = new StringReader(serializedXML);
        Beispielobjekt objectFromString = (Beispielobjekt) unmarshaller.unmarshal(stringReader);
        // Testen
        System.out
                .println(objectFromString.getData1() + " : " + objectFromString.getData2());
    }

}
