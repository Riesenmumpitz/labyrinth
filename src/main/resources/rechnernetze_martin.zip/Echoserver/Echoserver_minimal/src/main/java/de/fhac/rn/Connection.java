package de.fhac.rn;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Created by Martin Geßenich on 19.04.2017.
 */
public class Connection extends Thread {

    private Socket clientSocket;
    private boolean running;
    private Statistik stats;

    private String clientSentence = null;
    private String capitalizedSentence;
    private DataInputStream inFromClient;
    private DataOutputStream outToClient;

    public Connection(Socket clientSocket) throws IOException {
        this.clientSocket = clientSocket;
        inFromClient = new DataInputStream(clientSocket.getInputStream());
        outToClient = new DataOutputStream(clientSocket.getOutputStream());
    }

    public void sendToClient(String msg) {

    }

    public void run() {
        boolean flag = true;
        while (flag) {
            System.out.println("Reading input from client:");
            try {
                clientSentence = inFromClient.readUTF();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Read input: " + clientSentence);

            capitalizedSentence = clientSentence.toUpperCase() + '\n';
            System.out.println("Sending capitalized input to client");
            try {
                outToClient.writeUTF(capitalizedSentence);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if ("\\exit\n".equalsIgnoreCase(clientSentence) || "\\shutdown\n".equalsIgnoreCase(clientSentence)) {
                EchoServer.getServer().shutClientConnection(this);
                flag = false;
            }
        }

    }

    public Statistik getStats() {
        return stats;
    }


}
