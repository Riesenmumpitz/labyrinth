package de.fhac.rn;

/**
 * Created by Martin Geßenich on 19.04.2017.
 */
public class Statistik {
}
