package de.fhac.rn;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class EchoServerThread extends Thread {

    private Socket connectionSocket;
    private TCPServer server;

    public EchoServerThread(Socket connectionSocket) {
        this.connectionSocket = connectionSocket;
    }

    @Override
    public void run() {
//        try {
//            DataInputStream dataInputStream = new DataInputStream(clientSocket.getInputStream());
//            DataOutputStream dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
//            while (true) {
//				if (!clientSocket.isConnected()){
//				    break;
//                }
//                String in = dataInputStream.readUTF();
//                dataOutputStream.writeUTF("echo: " + in);
//
//                if ("\\exit".equalsIgnoreCase(in)) {
//                    System.out.println("Shutting Thread down..");
//                    break;
//                }
//            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        try {
            while (connectionSocket.isConnected()) {
                DataInputStream inFromClient = new DataInputStream(connectionSocket.getInputStream());
                DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
                String clientSentence = inFromClient.readUTF();

                if ("/exit".equals(clientSentence)) {
                    outToClient.writeUTF(clientSentence);
                    outToClient.flush();
                    System.out.println("Verbindung wird getrennt");
                    break;
                }


                String capitalizedSentence = clientSentence.toUpperCase();
                String clientAddress = connectionSocket.getRemoteSocketAddress().toString();
                String clientPort = ((Integer) connectionSocket.getPort()).toString();
                outToClient.writeUTF("Text:" + capitalizedSentence + "/Address:" + clientAddress + "/Port:" + clientPort);
                outToClient.flush();
            }
            connectionSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
