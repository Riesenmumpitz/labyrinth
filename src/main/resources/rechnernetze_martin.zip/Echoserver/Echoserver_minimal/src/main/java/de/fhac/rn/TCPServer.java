package de.fhac.rn;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by Martin Geßenich on 12.04.2017.
 */
public class TCPServer {
    public static void main(String argv[]) throws Exception {
        String clientSentence = null;
        String capitalizedSentence;
        ServerSocket welcomeSocket = new ServerSocket(6789);
        while (true) {
            System.out.println("Waiting for new connection...");
            Socket connectionSocket = welcomeSocket.accept();
            System.out.println("Accepted new connection.");


            DataInputStream inFromClient = new DataInputStream(connectionSocket.getInputStream());
            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

            while (true) {
                System.out.println("Reading input from client:");
                clientSentence = inFromClient.readUTF();
                System.out.println("Read input: " + clientSentence);

                capitalizedSentence = clientSentence.toUpperCase() + '\n';
                System.out.println("Sending capitalized input to client");
                outToClient.writeUTF(capitalizedSentence);
                if ("\\exit\n".equalsIgnoreCase(clientSentence) || "\\shutdown\n".equalsIgnoreCase(clientSentence))
                    break;
            }
            if ("\\shutdown\n".equalsIgnoreCase(clientSentence)){
                break;
            }
            System.out.println("Shutting down..");
        }
    }
}