package de.fhac.rn;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class EchoServer {

    private static EchoServer myself = new EchoServer();

    private EchoServer(){}

    private static List<Connection> connections = new ArrayList<>();
    private static boolean flag = true;

    public static EchoServer getServer(){
        return myself;
    }

    public void shutDown(){
        flag = false;
    }

    public void shutClientConnection(Connection connection) {
        connections.remove(connection);
    }

    public static void main(String[] args) throws Throwable {
        ServerSocket serverSocket = new ServerSocket(5000);
        while (flag) {
            System.out.println("Waiting for new connection...");
            Socket connectionSocket = serverSocket.accept();
            System.out.println("Accepted new connection.");

            Connection newConnection = new Connection(connectionSocket);
            newConnection.start();
            connections.add(newConnection);
        }
        serverSocket.close();
    }

}
