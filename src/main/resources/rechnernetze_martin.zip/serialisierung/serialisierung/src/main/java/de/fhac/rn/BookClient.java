package de.fhac.rn;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookClient {

    static Scanner scanner = new Scanner(System.in);
    static List<Book> books = new ArrayList<>();
    /* Variante 1 */
    static File bookFile = new File("./bookfileRaw.txt");
    /* Variante 2 */
//        static File bookFile = new File("./bookfileJSON.txt");

    public static void main(String[] args) {
        int input = -1;
        while (input != 0) {
            System.out.println("Choose");
            System.out.println(" (0) Quit program");
            System.out.println(" (1) Load books from file");
            System.out.println(" (2) Show Books");
            System.out.println(" (3) Add Book");
            System.out.println(" (4) Delete Book");
            System.out.println(" (5) Save books in file");
            input = scanner.nextInt();
            switch (input) {
                case 1:
                    loadBooks(bookFile);
                    break;
                case 2:
                    showBooks();
                    break;
                case 3:
                    addBook();
                    break;
                case 4:
                    deleteBook();
                    break;
                case 5:
                    saveBooks(bookFile);
                    break;
            }
        }
    }

    public static void loadBooks(File server) {

        if(!server.exists()){
            return;
        }

        /* Variante 1 */
        try (FileInputStream inPutStream = new FileInputStream(server)) {
            books.clear();
            ObjectInputStream in = new ObjectInputStream(inPutStream);
            Object object = in.readObject();
            books = (List<Book>) object;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        /* Variante 1 */

        /* Variante 2 */
//        JSONDeserializer<List<Book>> jsonDeserializer = new JSONDeserializer<>();
//        try {
//            books = jsonDeserializer.deserialize(new String(Files.readAllBytes(server.toPath())));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        /* Variante 2 */
    }

    public static void showBooks() {
        printTable();
        int counter = 1;
        for (Book book : books) {
            printBook(counter, book);
            counter++;
        }
        printBottom();
    }

    private static void printBottom() {
        System.out.println("====================================================================================");
    }

    private static void printBook(int counter, Book book) {
//        StringBuilder builder = new StringBuilder("| ").append(counter).append(" | ").append(book.getIsbn()).append(" | ")
//                .append(book.getTitel()).append(" | ").append(book.getAutor());

        String format = "| %1$3s | %2$17s | %3$-30s | %4$-10s %5$-10s |";


        System.out.println(String.format(format,counter, book.getIsbn(),book.getTitel(), book.getAutor().getVorname(), book.getAutor().getNachname()));
    }

    private static void printTable() {
//        978-3-12-732320-7
        System.out.println("====================================================================================");
        System.out.println("| Nr. |       ISBN        | Titel                          | Autor                 |");
    }

    public static void addBook() {
        System.out.println("Enter the new book's ISBN");
        String isbn = scanner.next();
        System.out.println("Enter the new book's author's forename");
        String forname = scanner.next();
        System.out.println("Enter the new book's author's surname");
        String surname = scanner.next();
        System.out.println("Enter the new book's title");
        String title = scanner.next();
        Book newBook = new Book(isbn, new Autor(forname, surname), title);
        books.add(newBook);
        scanner.nextLine();
    }

    public static void deleteBook() {
        showBooks();
        System.out.println("Enter the nunber of the book you want to delete");
        int number = scanner.nextInt();
        if (number > 0 && books.size() >= number ) {
            books.remove(number-1);
        }
    }

    public static void saveBooks(File server) {
        /* Version 1 */
        try (FileOutputStream fileOutputStream = new FileOutputStream(server)) {
            ObjectOutputStream out = new ObjectOutputStream(fileOutputStream);
            out.writeObject(books);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        /* Version 1 */

        /* Version 2 */
//        JSONSerializer jsonSerializer = new JSONSerializer();
//        String resultString = jsonSerializer.serialize(books);
//        try {
//            Files.write(server.toPath(),resultString.getBytes());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        /* Version 2 */
    }
}

/*
JSON Serialisierung hat den Vorteil, dass man
1. den Inhalt auch mal lesen / verstehen kann
2. man spart sich Umkodierung
3. Kann leicht von anderen Systemen gelesen werden
 */