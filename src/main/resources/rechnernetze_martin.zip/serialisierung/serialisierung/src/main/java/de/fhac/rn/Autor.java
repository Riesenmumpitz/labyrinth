package de.fhac.rn;

import java.io.Serializable;

/**
 * Created by Martin Geßenich on 05.04.2017.
 */
public class Autor implements Serializable {
    private String vorname;
    private String nachname;

    public Autor(String vorname, String nachname) {
        this.vorname = vorname;
        this.nachname = nachname;
    }

    public String getVorname() {
        return vorname;
    }

    public String getNachname() {
        return nachname;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Autor autor = (Autor) o;

        if (!getVorname().equals(autor.getVorname())) return false;
        return getNachname().equals(autor.getNachname());
    }

    @Override
    public int hashCode() {
        int result = getVorname().hashCode();
        result = 31 * result + getNachname().hashCode();
        return result;
    }
}
