package de.fhac.rn;

import java.io.Serializable;

/**
 * Created by Martin Geßenich on 05.04.2017.
 */
public class Book implements Serializable{
    private String isbn;
    private Autor autor;
    private String titel;

    public Book(String isbn, Autor autor, String titel) {
        this.isbn = isbn;
        this.autor = autor;
        this.titel = titel;
    }

    public String getIsbn() {
        return isbn;
    }

    public Autor getAutor() {
        return autor;
    }

    public String getTitel() {
        return titel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Book book = (Book) o;

        if (!getIsbn().equals(book.getIsbn())) return false;
        if (!getAutor().equals(book.getAutor())) return false;
        return getTitel().equals(book.getTitel());
    }

    @Override
    public int hashCode() {
        int result = getIsbn().hashCode();
        result = 31 * result + getAutor().hashCode();
        result = 31 * result + getTitel().hashCode();
        return result;
    }
}
