package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import javax.net.SocketFactory;
import javax.net.ssl.*;

import static sun.audio.AudioDevice.device;

//TODO import SSL-Classes

public class SSLClient {

    public static void main(String[] args) throws UnknownHostException, IOException {
        //TODO setup truststore to verfy server-certifiacte
        System.setProperty("javax.net.ssl.trustStore", "src/main/resources/keys/truststore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "geheim2");

        System.out.println("client starts");

        //TODO create SSLSocket
        SocketFactory sslSocketfactory = SSLSocketFactory.getDefault();
                SSLSocket sslSocket = (SSLSocket) sslSocketfactory.createSocket("192.168.1.120",6789);

        Scanner scanner = new Scanner(System.in);
        DataInputStream dataInputStream = new DataInputStream(sslSocket.getInputStream());
        DataOutputStream dataOutputStream = new DataOutputStream(sslSocket.getOutputStream());
        while (scanner.hasNextLine()) {
            dataOutputStream.writeUTF(scanner.nextLine());
            System.out.println(dataInputStream.readUTF());
        }
        scanner.close();
    }

//    protected ServerSocket createTLSServerSocket() throws IOException {
//        SSLContext sslContext = device.getSSLContext();
//        if (sslContext == null)
//            throw new IllegalStateException("TLS Context not initialized!");
//        SSLServerSocketFactory ssf = sslContext.getServerSocketFactory();
//        SSLServerSocket ss = (SSLServerSocket) ssf.createServerSocket();
//        ss.setEnabledProtocols(tlsProtocol);
//        ss.setEnabledCipherSuites(tlsCipherSuite);
//        ss.setNeedClientAuth(tlsNeedClientAuth);
//        return ss;
//    }
}