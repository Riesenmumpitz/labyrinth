package server;

import javax.net.ServerSocketFactory;
import javax.net.ssl.SSLServerSocketFactory;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

//TODO import SSL-Classes

public class SSLServer {

    public static void main(String[] args) throws IOException {
        //TODO set keystore and password
        System.setProperty("javax.net.ssl.keyStore", "src/main/resources/keys/rn-ssl.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "geheim");

        File file = new File("src/main/resources/keys/rn-ssl.jks");
        System.out.println(file.getAbsolutePath());

        System.out.println("server starts");
        //TODO create SSLServerSocket
        SSLServerSocketFactory sslServerSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        ServerSocket sslServerSocket = sslServerSocketFactory.createServerSocket(5000);
        Socket sslSocket = sslServerSocket.accept();
        DataInputStream dataInputStream = new DataInputStream(sslSocket.getInputStream());
        DataOutputStream dataOutputStream = new DataOutputStream(sslSocket.getOutputStream());
        while (true)
            dataOutputStream.writeUTF(dataInputStream.readUTF().toUpperCase());
    }

}