package client;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class ServerListener extends Thread {

    private Socket socket;
    DataInputStream dataInputStream;

    public ServerListener(Socket socket) throws IOException {
        this.socket = socket;
        dataInputStream = new DataInputStream(socket.getInputStream());
    }

    @Override
    public void run() {
        while (EchoClient.isRunning()) {
            String message = waitForMessage();
            processReceivedMessage(message);
        }
    }

    public void processReceivedMessage(String msg) {
        if ("/exit\n".equalsIgnoreCase(msg)) {
            System.out.println("Shutting Client down..");
            System.exit(0);
        }
        System.out.println(msg);
    }

    public String waitForMessage() {
        try {
            return dataInputStream.readUTF();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}