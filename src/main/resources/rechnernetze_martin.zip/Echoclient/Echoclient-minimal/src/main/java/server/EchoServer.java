package server;

import util.XMLSerialisation;

import javax.net.ssl.SSLServerSocketFactory;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class EchoServer {

    private static EchoServer myself = new EchoServer();

    private EchoServer() {
    }

    private static List<Connection> connections = new ArrayList<>();
    private static boolean flag = true;

    public static EchoServer getServer() {
        return myself;
    }

    public void shutDown() {
        flag = false;
    }

    public void shutClientConnection(Connection connection) {
        connections.remove(connection);
    }

    public void start(int port) throws IOException {

        SSLServerSocketFactory sslServerSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        ServerSocket sslServerSocket = sslServerSocketFactory.createServerSocket(port);
        XMLSerialisation serializer = new XMLSerialisation(sslServerSocket.getInetAddress().getHostName());

        while (flag) {
            System.out.println("Waiting for new connection...");
            Socket connectionSocket = sslServerSocket.accept();
            System.out.println("Accepted new connection.");

            Connection newConnection = new Connection(connectionSocket);
            newConnection.start();
            connections.add(newConnection);
        }
        sslServerSocket.close();
    }

    public String getStats() {
        StringBuilder builder = new StringBuilder();
        connections.stream()
                .sorted(Comparator.comparing(connection -> connection.getClientSocket().getInetAddress().getHostName()))
                .forEach(connection -> {
                        builder.append(connection.getClientSocket().getInetAddress().getHostAddress())
                                .append("\n")
                                .append(connection.getStats().toString())
                                .append("\n");
                });
        return builder.toString();
    }

    public void broadcast(String msg) {
        connections.forEach(connection -> {
            try {
                connection.sendToClient(msg);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
