package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Created by Martin Geßenich on 19.04.2017.
 */
public class Connection extends Thread {

    private Socket clientSocket;
    private Statistik stats = new Statistik();

    private String clientSentence = null;
    private String capitalizedSentence;
    private DataInputStream inFromClient;
    private DataOutputStream outToClient;

    private boolean flag;

    public Connection(Socket clientSocket) throws IOException {
        this.clientSocket = clientSocket;
        inFromClient = new DataInputStream(clientSocket.getInputStream());
        outToClient = new DataOutputStream(clientSocket.getOutputStream());
        flag = true;
    }

    public void sendToClient(String msg) throws IOException {
        capitalizedSentence = msg.toUpperCase() + '\n';
        System.out.println("Sending capitalized input to server");
        outToClient.writeUTF(capitalizedSentence);
    }

    public void run() {

        while (flag) {
            System.out.println("Reading input from server:");
            try {
                clientSentence = inFromClient.readUTF();
                System.out.println("Read input: " + clientSentence);

                if (clientSentence != null && clientSentence.startsWith("/broadc")) {
                    EchoServer.getServer().broadcast(clientSentence.replace("/broadc", ""));
                } else if ("/showstat".equalsIgnoreCase(clientSentence)) {
                    sendToClient(stats.toString());
                } else if ("/showallstat".equalsIgnoreCase(clientSentence)) {
                    sendToClient(EchoServer.getServer().getStats());
                } else if ("/exit".equalsIgnoreCase(clientSentence) || "/shutdown".equalsIgnoreCase(clientSentence)) {
                    sendToClient(clientSentence);
                    System.out.println("Shutting down connection to server");
                    EchoServer.getServer().shutClientConnection(this);
                    flag = false;
                } else {
                    stats.addToCharCount(clientSentence.length());
                    stats.addToMsgCount(1);
                    if (stats.getLongest() < clientSentence.length()) {
                        stats.setLongest(clientSentence.length());
                    }
                    if (stats.getShortest() > clientSentence.length()) {
                        stats.setShortest(clientSentence.length());
                    }
                    sendToClient(clientSentence);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Statistik getStats() {
        return stats;
    }

    public Socket getClientSocket() {
        return clientSocket;
    }
}
