package client;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

public class EchoClient {

    private DataOutputStream dataOutputStream;
    private static Scanner scanner = new Scanner(System.in);
    private BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
    private static boolean running = true;
    private static Socket socket;

    public EchoClient(Socket socket) throws IOException {
        dataOutputStream = new DataOutputStream(socket.getOutputStream());
        this.socket = socket;
    }

    public static void main(String[] args) throws Throwable {
        System.setProperty("javax.net.ssl.trustStore", "src/main/resources/truststore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "pwgen");

        SocketFactory sslSocketfactory = SSLSocketFactory.getDefault();
        Socket socket = sslSocketfactory.createSocket("192.168.1.120", 6789);

        EchoClient client = new EchoClient(socket);
        ServerListener clientThread = new ServerListener(socket);
        clientThread.start();
        client.start();

        scanner.close();
    }

    private void start() {
        while (isRunning()) {
            String message = promptForNewMessage();
            sendToServer(message);
        }
    }

    public void sendToServer(String msg) {
        System.out.println("LOG: Sending msg to client:" + msg);
        try {
            dataOutputStream.writeUTF(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean isRunning() {
        return running;
    }

    public String promptForNewMessage() {

        try {
            return inFromUser.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }
}