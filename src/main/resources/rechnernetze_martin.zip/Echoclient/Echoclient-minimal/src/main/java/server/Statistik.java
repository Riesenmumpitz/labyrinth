package server;

import java.io.File;

/**
 * Created by Martin Geßenich on 19.04.2017.
 */
public class Statistik {
    private int shortest;
    private int longest;
    private int count;
    private int size;

    public Statistik() {
    }

    public Statistik(File file)
    {
    }

    public Statistik merge( Statistik other){
        return null;
    }

    @Override
    public String toString() {
        return "Statistik{" +
                "shortest=" + shortest +
                ", longest=" + longest +
                ", count=" + count +
                '}';
    }

    public void save(File file){

    }

    public int getShortest() {
        return shortest;
    }

    public void setShortest(int shortest) {
        this.shortest = shortest;
    }

    public int getLongest() {
        return longest;
    }

    public void setLongest(int longest) {
        this.longest = longest;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void addToCharCount(int length) {
        size += length;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void addToMsgCount(int i) {
        count += 1;
    }
}
